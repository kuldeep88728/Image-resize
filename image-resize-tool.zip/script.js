const imageInput = document.getElementById("imageInput");
const qualityRange = document.getElementById("qualityRange");
const qualityValue = document.getElementById("qualityValue");

qualityRange.addEventListener("input", () => {
  qualityValue.textContent = qualityRange.value + "%";
});

function resizeImage() {
  const file = imageInput.files[0];
  if (!file) {
    alert("Please upload an image first.");
    return;
  }

  const reader = new FileReader();
  reader.readAsDataURL(file);

  reader.onload = function (event) {
    const img = new Image();
    img.src = event.target.result;

    img.onload = function () {
      const canvas = document.getElementById("canvas");
      const ctx = canvas.getContext("2d");

      canvas.width = img.width;
      canvas.height = img.height;

      ctx.drawImage(img, 0, 0);

      const quality = parseInt(qualityRange.value) / 100;

      canvas.toBlob(
        function (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "resized-image.jpg";
          a.click();
        },
        "image/jpeg",
        quality
      );
    };
  };
}
